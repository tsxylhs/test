package edu.lhs.entity;

public class Vshopnote {
private String Vnumber;
private String CakeId;
private String Caketime;
public String getVnumber() {
	return Vnumber;
}
public void setVnumber(String vnumber) {
	Vnumber = vnumber;
}
public String getCakeId() {
	return CakeId;
}
public void setCakeId(String cakeId) {
	CakeId = cakeId;
}
public String getCaketime() {
	return Caketime;
}
public void setCaketime(String caketime) {
	Caketime = caketime;
}
}
