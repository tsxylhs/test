package edu.lhs.entity;

public class adm {
@Override
	public String toString() {
		return "adm [Aname=" + Aname + ", Azh=" + Azh + ", Apasw=" + Apasw + "]";
	}
private String Aname;
private String Azh;
private String Apasw;
public String getAname() {
	return Aname;
}
public void setAname(String aname) {
	Aname = aname;
}
public String getAzh() {
	return Azh;
}
public void setAzh(String azh) {
	Azh = azh;
}
public String getApasw() {
	return Apasw;
}
public void setApasw(String apasw) {
	Apasw = apasw;
}

}
