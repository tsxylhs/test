package edu.lhs.entity;

public class orders {
 private String Dnumber;
 private String Vnumber;
 private String Dtime;
public String getDnumber() {
	return Dnumber;
}
public void setDnumber(String dnumber) {
	Dnumber = dnumber;
}
public String getVnumber() {
	return Vnumber;
}
public void setVnumber(String vnumber) {
	Vnumber = vnumber;
}
public String getDtime() {
	return Dtime;
}
public void setDtime(String dtime) {
	Dtime = dtime;
}
}
